# SRT Renamer v6 — بثلاث تابات

## الجديد في v6 (تحسين بناء الروابط)
- ✅ **slugs أكثر دقة** — يشيل `[`, `]`, `()` من اسم الملف قبل بناء الـ slug
- ✅ **article stripping** — يجرّب بدون `the-` / `a-` / `an-` تلقائياً
- ✅ **year range موسّع** — يجرّب من 2015 لـ 2026 للمسلسلات
- ✅ **API search أقوى** — يجرّب 5 نتائج بدل 3، ويدعم كل صيغ الـ response
- ✅ **log أوضح** — يوضح إن API هو الأول وWebView fallback بس للضرورة


- ✅ **🤖 Auto Mode** — تاب جديد كامل للمراقبة التلقائية
- ✅ تكامل مع **qBittorrent Web UI** (اختياري)
- ✅ مراقبة **مجلد الملفات مباشرة** بدون qBittorrent
- ✅ جلب ترجمة عربية من **SubSource** تلقائياً
- ✅ فك الـ ZIP ووضع الـ SRT بجانب الفيديو تلقائياً
- ✅ **إشعارات** عند اكتمال كل ترجمة
- ✅ **BootReceiver** — يبدأ المراقبة تلقائياً بعد إعادة التشغيل
- ✅ سويب بالإصبع للتنقل بين التابات

## التابات
1. 🎬 **SRT Renamer** — الوضع اليدوي (اختار مجلد + ZIP)
2. ⚡ **Auto bt4g** — ابحث عن تورنت وافتحه
3. 🤖 **Auto Mode** — مراقبة تلقائية كاملة

## إزاي تستخدم Auto Mode
1. افتح تاب 🤖 Auto
2. اختار مجلد التورنت (نفس مجلد التحميل)
3. (اختياري) أدخل IP + Port + Password لـ qBittorrent
4. اضغط "ابدأ المراقبة"
5. خلّص! أي فيلم/حلقة تخلص — الترجمة تيجي تلقائياً ✨

## الصلاحيات المطلوبة
- `READ_MEDIA_VIDEO` — قراءة الفيديوهات
- `INTERNET` — جلب الترجمات من SubSource
- `POST_NOTIFICATIONS` — إشعارات الترجمة
- `RECEIVE_BOOT_COMPLETED` — إعادة التشغيل التلقائي
- `FOREGROUND_SERVICE` — للمراقبة المستمرة

## Build
- minSdk 24 (Android 7+)
- targetSdk 34
- Kotlin + Coroutines
- No external subtitle API needed
