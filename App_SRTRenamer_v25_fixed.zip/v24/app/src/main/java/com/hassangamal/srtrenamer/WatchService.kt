package com.hassangamal.srtrenamer

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * ForegroundService — يحافظ على مراقبة المجلد حتى لو التطبيق مقفول تماماً.
 * MainActivity تشغّله وتوقفه عبر startService/stopService.
 */
class WatchService : Service() {

    companion object {
        const val CHANNEL_ID  = "watch_service_ch"
        const val NOTIF_ID    = 1
        const val ACTION_STOP = "com.hassangamal.srtrenamer.STOP_WATCH"
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val stopIntent = Intent(this, WatchService::class.java).apply { action = ACTION_STOP }
        val stopPi    = PendingIntent.getService(this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val openIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val openPi = PendingIntent.getActivity(this, 1, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("🟢 Auto Subs — يراقب")
            .setContentText("التطبيق يراقب المجلد في الخلفية")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopPi)
            .build()

        startForeground(NOTIF_ID, notif)
        return START_STICKY   // يعيد تشغيل نفسه لو Android أوقفه
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        // أبلغ MainActivity بالتوقف (في حال Android هو من أوقفه)
        sendBroadcast(Intent("com.hassangamal.srtrenamer.SERVICE_STOPPED"))
    }

    private fun createChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "مراقبة المجلد",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "إشعار دائم يبقي مراقبة المجلد نشطة" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
}
