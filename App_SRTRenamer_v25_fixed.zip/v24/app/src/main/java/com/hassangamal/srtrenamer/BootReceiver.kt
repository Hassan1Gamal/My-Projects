package com.hassangamal.srtrenamer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Restarts Auto Mode watching after device reboot,
 * if the user had it running before shutdown.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("autosubs_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("auto_was_running", false)) {
            // Launch MainActivity invisibly; it will call startAuto() from loadPrefs()
            val launch = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("from_boot", true)
            }
            context.startActivity(launch)
        }
    }
}
